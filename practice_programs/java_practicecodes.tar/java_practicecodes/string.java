// // // public class tring {
// // //     public static void main(String[] args) {
// // //         String str = "Anything";
// // //         for (int i = 0; i < str.length(); i++) {     
// // //             System.out.println(str.charAt(i));
// // //         }
// // //     }

// // 
// // public class string {
// //     public static void main(String[] args) {
// //         String str ="java programming";
// //         int count =0;
// //         for(char c:str.toCharArray()){
// //         if ("aeiouAEIOU".indexOf(c) !=-1)
// //             count++;
// //         }
// //         System.out.println("vowels="+count);
// //     }

// // }
// // public class string {
// //   public static void main(String[] args) {
// //          String str ="java programming";
// //          int count =0;
// //          for(char c:str.toCharArray()){
// //                      if ("aeiouAEIOU".indexOf(c) !=-1)
// //                         count++;
// //         }
// //          System.out.println("vowels="+count);

// //         }
// //     }

// import javax.print.DocFlavor.STRING;

// public class string {
//   public static void main(String[] args) {
//          String str ="java programming";
//          string vowels ="aeiouAEIOU";
//          string result =" ";
//           for(char c:str.toCharArray()) {
//             if (vowels.indexOf(c) !=-1&& result.indexOf(c)==-1{
//                 result+==c;

//                 System.out.println("vowels="+ result);
//             }
//             }
//         }
//     }
        




   // revers a string

  


  
