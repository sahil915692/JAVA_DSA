// // // public class sumofevennoinarray{
// // //     public static void main(String[] args) {
// // //         int[] arr = {10, 15, 22, 33, 40, 55};
// // //         int sum = 0;
// // //         for (int num : arr) {
// // //             if (num % 2 == 0) {
// // //                 sum += num;
// // //             }
// // //         }
// // //         System.out.print("Sum of even numbers: " + sum);
// // //     }
// // // }

// // // merge two element 
// // public class MergeArrays {
// //     public static void main(String[] args) {
// //         int[] arr1 = {1, 7, 3};
// //         int[] arr2 = {5, 6, 86};
// //         int[] merged = new int[arr1.length + arr2.length];
// //         int i = 0; 
// //         for(int x:arr1)merged[i++]=x;
// //        for(int x:arr2)merged[i++]=x;
// //        for(int x:merged)
// //        System.out.print(x+" ");
// //     }
// // }
//         //    
//          public class MergeArrays {
//     public static void main(String[] args) {
//         for (int j = 0; j <= 0; j++) {
//             System.out.print("*");
//         }
//         System.out.println(); 
//     }

// }



