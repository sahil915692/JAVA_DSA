// // public class arrayexample {
// //     public static void main(String[]arg){
// //         int arr[]={1,2,3,4,5};
// //         for(int i=0;i<5;i++){
// //             System.out.println(arr[i]);
// //         }
// //     }   
// // }
// // find largest element tin the arrays


// // public class arrayexample {
// //   public static void main(String[]arg) {
// //     int arr[]={1,2,3,6,5,8};
// //     int largest = arr[0];
// //         for (int i : arr) {
// //             if (arr[i] > largest) {
// //                 largest = arr[i];
// //                 System.out.println(arr[i]);
// //             }
// // } 
// //     }
// // } 

// // public class arrayeExample {
// //     public static void main(String[] arg) {
// //         int arr[] = {1, 2, 3, 6, 5, 8,44,458,51,541,5415,445,};
// //         int max = arr[0];

// //         for (int i : arr) {
// //             if (i > max) {
// //                 max= i;
// //             }
// //         }
// //         System.out.println("Largest numder is: " + max);
// //     }
// // }
// // sum of numders
// // public class arrayeExample {
// //     public static void main(String[] args) {
// //         int arr[]={2,54,7,5,5};
// //         int sum =0;
// //         for ( int i:arr ){
// //             sum +=i;
           
// //         }
// //          System.err.println("sum ="+sum);
// //     }
// // }


// // find smallest numderr

// // public class argrrayexample {
// //   public static void main(String[]arg) {
// //     int arr[]={55,59,5,8,9};
// //     int smallest= arr[0];
// //         for (int i : arr) {
// //             if (i < smallest) {
// //                 smallest = i;
// //                 System.out.println(i);
// //             }
// // } 
// //     }
// // }
// //   // revers the argrray
// //   public class argrrayexample {
// //      public static void main(String[]arg) {
// //     int arr[] = {12,6,65,65,5,6};
// //     for ( int i =0; arr. length- 1; i>=0;i-){
// //     }
// //      System.out.println(arr[i]+" "); 
// //      }
// //     }
//  // searching an element in an array
// // public class ArrayExample {
// //     public static void main(String[] args) {
// //         int arr[] = {10, 20, 30, 40, 50};
// //         boolean found = false;
// //         int key = 30;
// //         for (int i : arr) {
// //             if (i == key) {
// //                 found = true;
// //                 System.out.println("Found:"+ i);
// //             }
// //         }
// //         if (!found) {
// //        System.out.println("Element not found in the array.");
// //         }
// //     }
// // }
// //searching an element in an array
// // public class ArrayExample {
// //     public static void main(String[] args) {
// //         int arr[] = {10, 20, 30, 40, 50};
// //         int key = 30;
// //         int index = -1; 
// //         for (int i = 0; i < arr.length; i++) {
// //             if (arr[i] == key) {
// //                 index = i;
// //                 break;
// //             }
// //         }
// //         if (index != -1) {
// //             System.out.println("Key " + key + " found at index " + index);
// //         } else {
// //             System.out.println("Key " + key + " not found in the index"+index);
// //         }
// //       }
// // }
//            //  copy one array to another
// public class ArrayCopyExample {
//     public static void main(String[] args) {
//         int[] arr1 = {10, 20, 30, 40, 50};
//         int[] arr2 = new int[arr1.length];
//         for (int i = 0; i < arr1.length; i++) {
//             arr2[i] = arr1[i];
//         }
//         for (int i : arr2) {
//             System.out.println(i + " ");
//         }
//     }
// }






