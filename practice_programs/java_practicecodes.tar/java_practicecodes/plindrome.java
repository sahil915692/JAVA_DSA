// // // // // public class palindrome {
// // // // //     public static void main(String[] args) {
// // // // //         String str  = "gopal";
// // // // //         String rev  =" ";
// // // // //         for(int i  = str.length()-1 ;i>=0;i--){
// // // // //             rev   += str.charAt(i);
// // // // //     }
// // // // //     System.out.println(str.equals(rev) ? "plindrome":"not plindrome");
// // // // // }
// // // // // }s


// // // // // convert string to uppercase
// // // // // public class palindrome {
// // // // //     public static void main(String[] args) {
// // // // //         String str  = "sahil";
// // // // //         System.out.println(str.toUpperCase());
// // // // //     }
// // // // // }
// // // //        //convert string to LOWER case
// // // // // public class palindrome {
// // // // //     public static void main(String[] args) {
// // // // //         String str  = "SAHIIL";
// // // // //         System.out.println(str.toLowerCase());
// // // // //     }
// // // // // }
// // // // // COUNT words in string
    
// // // // public class palindrome {
// // // //     public static void main(String[] args) {
// // // //        String str ="andhale" ;
// // // //        String[] words=str.split("");
// // // //        int wordscount = words.length;
// // // //        System.out.println("numders of words:" + wordscount);

// // // //     }
// // // // }

// // //   // replacworld
// // //   public class palindrome {
// // //    public static void main(String[] args, String target) {
// // //         String str ="andhale" ;
// // //         String repleacedString = str.replace(target:"andhale", "sahil");
// // //         System.out.println(" original: " + str);
// // //         System.out.println(" modified:"+repleacedString);

    
// // //    }
// // // }
// // //     public class plindrome{
// // //     public static void main(String[] args) {
// // //         String str = "sahil";
// // //         String replacedString = str.replace("sahil", "andhale");
// // //         System.out.println("Original: " + str);
// // //         System.out.println("Modified: " + replacedString);
// // //     }
// // // }

// //     // 

// // public class plindrome{
// //   public static void main(String[] args) {
// //     String a="sahil";
// //     String b="sahil";
// //     System.out.println(a.equals(b));
    
// //   }
// // }
// // public class plindrome{
// //   public static void main(String[] args) {
// //      String a="sahil";
// //     String b="andhale";
// //      System.out.println(a+""+b);
// //   }
// // }
    
//     public class plindrome{
//  public static void main(String[] args){
//     String a= " sahil";
//     System.out.println("length of given String is:"+a.length());
//  }
// }
//     public class plindrome{
//    public static void main(String[] args){
//    String a= "sahil";
//    System.out.println(string.contains("sahil"));
//     }
// }

   //print each world in line 
//    public class plindrome{
//     public static void main(String[] args){
//     System.out.println ("sahil");
//     }
// }


//  public class plindrome {
 
//     public static void main(String[] args) {
//     String str = ("java is a powerful" );
//     String[] world = str.split("\\s+");
//     for ( String word : word) {
//         System.out.println(word);

//     }
// }
//  }
//  public class plindrome {
 
//     public static void main(String[] args) {
//         String str ="APPLE"
//         char
//         int count=;
//         for (char:
//     }
//  }



