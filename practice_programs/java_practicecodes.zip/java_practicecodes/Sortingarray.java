// import java.util.Arrays; 
// public class Sortingarray {
//     public static void main(String[] args) {
//         int[] arr = {15, 24, 4, 62, 25, 5, 358};
//         Arrays.sort(arr);
//         System.out.println("Sorted Array:");
//         for (int num : arr)
//          {
//             System.out.print(num + " ");
//         }
//     }
// }
//